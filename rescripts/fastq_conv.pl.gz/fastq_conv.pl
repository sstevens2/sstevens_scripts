#!/usr/bin/perl
my $mod = "11/21/11 11:44 AM";
my $version = "0.1";
my $author = "Nick Youngblut";
#--------------------- version log ---------------------#
#
#
#-------------------------------------------------------#

### packages/perl_flags
use strict;
use warnings;
use Data::Dumper;
use Getopt::Long;
use Bio::SeqIO;

### global variables
my ($error);

### I/O
if ($#ARGV < 0){
	&usage;
	}
my ($input, $fi, $fo, $verbose, $outfile);
GetOptions(
	   "input=s" => \$input,
	   "fi=s" => \$fi,
	   "fo=s" => \$fo,
	   "verbose" => \$verbose,
	   "outfile=s" => \$outfile,
	   "help|?" => \&usage # Help
	   );

### Input error check
if(! $input){
	$error = "Provide fastq file name.\n";
	error_routine($error, 1);
	}
if(! $fi){
	$error = "Provide input format of fastq file (-fi option).\n";
	error_routine($error, 1);
	}
if(! $fo){
	$error = "Provide output format of fastq file (-fo option).\n";
	error_routine($error, 1);
	}
if(! $outfile){ ($outfile = $input) =~ s/\.[^\.]+$|$/_e.fq/; }

### Routing main subroutines
seq_IO($input, $fi, $fo, $outfile);

#----------------------Subroutines----------------------#
sub seq_IO{
	my ($input, $fi, $fo, $outfile) = @_;
	my $in = Bio::SeqIO->new(-format => 'fastq', -variant => $fi, -file => $input);
	my $out = Bio::SeqIO->new(-format => 'fastq', -variant => $fo, -file => "> $outfile");
	my $cnt=0; my $begin;
	if($verbose){ $begin = file_time();}
	while(my $seq = $in->next_seq){
		if($verbose && $cnt%100000 == 0 && $cnt!=0){ print " $cnt sequences written; ", file_time()-$begin, " minutes processing\n";}
		$out -> write_seq($seq);
		$cnt++;
		}
	print "  File conversion complete.\n  Output: $outfile\n";
	}

sub file_time{
	my @times = localtime(time);
	#my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time); 
	$times[2] = $times[2]*60;
	$times[3] = $times[3]*3600;
	$times[4] = $times[4]*108000;
	$times[1] = $times[1]+$times[2]+$times[3]+$times[4];
	return $times[1];
	}

sub error_routine{
	my $error = $_[0];
	my $exitcode = $_[1];
	print STDERR "ERROR: $error\nSee help: [-h]\n";
	exit($exitcode);
	}

sub usage {
 my $usage = <<HERE;
Usage:
  fastq_conv.pl -i -fi -fo [-o] [-v]
Options:
  -i	Input fastq file name.
  -fi	Input fastq file format.
  -fo	Output fastq file format.
  -o	[optional]. Output fastq file name.
  -v	[optional]. Verbose output. Gives status updates.
Description:
  Program converts fastq file into the various 
  quality score encodings.
  
  Available formats (-fi, -fo options):
	sanger
	solexa (a.k.a. Illumina 1.0)
	illumina (a.k.a. Illumina 1.3+)
	
  Example usage:
  	fastq_conv.pl -i FILE.fastq -fi sanger
  		-fo illumina
Notes:
	Version: $version
	Last Modified: $mod
	Author: $author
	# requires Bioperl
	
HERE
	print $usage;
    exit(1);
}