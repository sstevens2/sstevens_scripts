#! /usr/bin/perl
# SCRIPTNAME.pl
use warnings;

open SCF, "< 454Scaffolds.fna" or die "cannot open scaf\n";
open SCT, "< 454Scaffolds.txt" or die "cannot open scaffold.txt\n";
open PAIR, "< 454PairStatus.txt" or die "cannot open pair\n";
open TABLE, "> table.tab" or die "cannot open table\n";
open PRIMER3, "> primer3.input.txt" or die "cannot open primer3 input\n";


#SS02003X1B08	TruePair	36825	scaffold00001	253629	-	scaffold00001	216804	+	

while($line=<SCF>){
	chomp($line);
	if($line=~/^>(scaffold\d+)/){
		#this is the name line of a new fasta sequence
		$name=$1;
		$scaf{$name}=''; #start an empty string for this new sequence
	}
	else{
		#this is a line of sequence, so add it to the current sequence being read
		$scaf{$name}.=$line;
	}
}

while($line=<SCT>){
	chomp($line);
#scaffold00001	1192909	1227175	69	W	contig00035	1	34267	+
#scaffold00001	1227176	1228437	70	N	1262	fragment	yes
	if($line=~/^(scaffold\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+N\s+\d+\s+fragment/){
		$scaffold=$1;
		$start=$2;
		$end=$3;
		$gaplength=$4;
		if(! defined $gapstart{$scaffold}){
			$gapstart{$scaffold}[0]=$start;
			$gapend{$scaffold}[0]=$end;
			$gapind{$scaffold}[0]="a"; #these will change to 1 when the gap has been handled
		}
		else{
			push @{$gapstart{$scaffold}}, $start;
			push @{$gapend{$scaffold}}, $end;
			push @{$gapind{$scaffold}}, "a";
		}
	}
}

print TABLE "cosmid\tscaffold\tstart\tend\n";

while($line=<PAIR>){
	if($line=~/^(SS\S+)\s+TruePair.*(scaffold\d+)\s+(\d+).*(scaffold\d+)\s+(\d+)/){
		#Line starts with SS, so it is from a cosmid
		
		$cosmid = $1;
		$name = $2;
		$start = int $3;
		$scaffold = $4;
		$end = int $5;
		$count=0;
		@found=();
		if($end<$start){
			$temp=$start;
			$start=$end;
			$end=$temp;
		}
		$indq=0;
		foreach $gapst (@{$gapstart{$scaffold}}){
			if($indq==1){$smod=$start+1;$emod=$end+1;print "$smod\t$emod\t$gapst\n";}
			if($start<$gapst && $gapst<$end){
				if(! defined $found[0]){
					$found[0]=$count;
					
				}
				else{push @found, $count;}
			}
			$count++;
		}
		if(! defined $found[0]){
			next;
		}
		foreach $i (@found){
			if(@{$gapind{$scaffold}}[$i] ne "a"){next;}
			@{$gapind{$scaffold}}[$i]=$cosmid;
			$gstart=@{$gapstart{$scaffold}}[$i];
			$gend=@{$gapend{$scaffold}}[$i];
			$gaplength=$gend-$gstart;
			$seq = substr $scaf{$name}, @{$gapstart{$scaffold}}[$i]-200, $gaplength+400;
			#						(a) length in front of gap ^	      (b) x2 ^		
			$targetEnd = $gaplength+150;
			# (a) + no primer region ^
			# no primer region goes in SEQUENCE_TARGET below along with $targetEnd
			print PRIMER3 "SEQUENCE_ID=$cosmid.$scaffold.$gstart\nSEQUENCE_TEMPLATE= $seq\nSEQUENCE_TARGET=150,$targetEnd\nPRIMER_TASK=pick_sequencing_primers\nPRIMER_LIBERAL_BASE=1\nP3_FILE_FLAG=1\n=\n";
		}
	
		$length=$end-$start;
		$seq=substr $scaf{$name}, $start, $length;
		if(!($seq=~/N/)){next;}#This region does not contain a gap, so proceed to the next cosmid pair
		open OUT, "> $cosmid.fas" or die "cannot open out\n";	
		print OUT ">$cosmid\n$seq\n";
		print TABLE "$cosmid\t$name\t$start\t$end\n";
			
	}
}

system("primer3_core -format_output < primer3.input.txt");
