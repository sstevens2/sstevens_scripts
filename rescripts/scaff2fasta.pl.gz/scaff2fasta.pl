#!/usr/bin/perl

sub reverse_complement {

    local($seq) = @_;
    $seq = reverse($seq);
    $seq =~ tr/ACGT/TGCA/;
    return $seq;
}

if(@ARGV < 3) {
 
    print ("\nUSAGE: scaff2fasta.pl <scaff> <seqfile> <outfile>\n\n".
           "scaff\t= File containing scaffold information in .scaff format\n".
           "seqfile\t= Multi-Fasta file containing contig sequences\n".
	   "outfile\t= File to which sequences corresponding to the scaffolds will be output\n\n");
 
    exit;
}

($scaff_file, $seq_file, $out_file, $gap_model) = @ARGV;

#
# gap_model = 0 (default) => Insert NNNNNTTAATTAATTAANNNNN if gap has positive size estimate.
#             1 => Insert as many N's as estimate.
#   

open(SEQ, $seq_file);
$data = join("", <SEQ>);
close(SEQ);

while($data =~ m/\>(\S+).*\n([^\>]+)/g) {

    $name = $1; $seq = $2; $seq =~ s/\n//g;
    $sequences{$name} = $seq;
}

open(OUT, ">$out_file");
$data = `cat $scaff_file`;

while($data =~ m/(\>.*\n)([^\>]+)/g) {

    print OUT $1;
    @contigs = split(/\n/, $2);

    for $i (0..$#contigs) {

	($name, $orientation, $size, $offset) = split(/\s+/, $contigs[$i]);
    
	$start = 1; $end = $size;
	if($name =~ m/\{/) {

	    $name =~ s/(.*)\{(.*),(.*)\}/\1/; $start = $2; $end = $3;
	    ($start, $end) = sort {$a <=> $b} ($start, $end);
	}

	print "Error: Couldn't find $name.\n" if($sequences{$name} eq "");
    
	$seq = $sequences{$name}; 
	printf "Error: For $name, expected $size bp but got %d bp.\n", length($seq) if(length($seq) != $size);
	$seq = substr($seq, $start-1, $end-$start+1); $seq =~ s/(\S{80})/\1\n/g;
	$seq = reverse_complement($seq) if($orientation eq "EB");
	$gap = ($gap_model == 1 ? ($offset > 0 ? "N"x$offset : "") :
		($offset > 0 ? "NNNNNTTAATTAATTAANNNNN" : ""));
	print OUT "$seq$gap\n";
    }
}
close(SCAFF);
close(OUT);    


